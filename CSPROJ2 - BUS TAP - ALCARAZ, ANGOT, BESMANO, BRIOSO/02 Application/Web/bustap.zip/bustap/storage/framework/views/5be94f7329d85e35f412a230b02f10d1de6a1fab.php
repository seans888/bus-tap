<?php $__env->startSection('title'); ?> - Reset Password <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> RESET PASSWORD <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form class="register-form" method="POST" action="<?php echo e(route('password.request')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <div>
            <label for="email">E-Mail Address</label>
            <div>
                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required>
            
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
                
        <div>
            <label for="password">Password</label>
            <div>
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>
            
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
                
        <div>
            <label for="password-confirm">Confirm Password</label>
            <div>
                <input id="password-confirm" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" placeholder="Password" required>
                
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        &nbsp;
        
        <div>
            <div>
                <button type="submit" class="btn btn-block btn-info">
                    RESET PASSWORD
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template-accounts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>