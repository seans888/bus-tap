<nav class="navbar navbar-expand-md fixed-top navbar-transparent">
    <div class="container">
        <div class="navbar-translate">
            <?php if(auth()->guard()->guest()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Bus Tap')); ?>

                </a>
            <?php else: ?>
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    <?php echo e(config('app.name', 'Bus Tap')); ?>

                </a>
            <?php endif; ?>
        </div>
        
        <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">Sign In</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('register')); ?>" class="nav-link">Sign Up</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('logout')); ?>" class="nav-link"
                            onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                            Sign Out
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>