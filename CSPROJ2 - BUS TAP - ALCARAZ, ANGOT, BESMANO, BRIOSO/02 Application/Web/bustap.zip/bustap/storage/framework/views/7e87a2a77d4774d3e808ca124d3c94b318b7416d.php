<?php $__env->startSection('title'); ?> - View Route Information <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if($route->route_map != "no_image.png"): ?>
            <div class="col-lg-4 col-md-5">
                <div class="card card-user">
                    <img src='/storage/route_maps/<?php echo $route->route_map; ?>' alt="Route Map" width="325" class="img-rounded img-no-padding img-responsive">
                </div>
            </div>
        <?php endif; ?>
    
        <div class="col-lg-8 col-md-7">
            <div class="card">
                <div class="header">
                    <h4 class="title">View Route Information</h4>
                </div>
                <div class="content">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Code</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_code; ?>">
                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group">
                                <label>Route Name</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_name; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Status</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_availability; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label>Operating Schedule</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_opschedule; ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Fare</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_fare; ?>">
                            </div>
                        </div>
                    </div>

                    <table>
                        <td width=100>
                            <a href="/routes/<?php echo e($route->id); ?>/edit" class="btn btn-info btn-block">Edit</a>
                        </td>
                        <td width=25>&nbsp;</td>    
                        <td width=100>
                            <?php echo Form::open(['action' => ['RoutesController@destroy', $route->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

                            <?php echo Form::close(); ?> 
                        </td>            
                    </table>
            
                </div>
            </div>
        </div>      
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>