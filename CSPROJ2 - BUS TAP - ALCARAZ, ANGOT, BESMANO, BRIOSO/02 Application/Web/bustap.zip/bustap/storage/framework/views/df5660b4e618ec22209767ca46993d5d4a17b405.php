<?php $__env->startSection('title'); ?> - View Buses <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Buses</h4>
            </div>
            <div class="content">
                    <?php if(count($buses) > 0): ?>
                    <table class="table">
                        <thead class="text-info">
                            <th>Plate Number</th>
                            <th>Status</th>
                            <th>Route</th>
                            <th></th>
                            <th></th>    
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="/buses/<?php echo e($bus->id); ?>"><?php echo e($bus->bus_platenumber); ?></td>
                                    <td><?php echo e($bus->bus_availability); ?></td>
                                    <td>
                                        <?php if(count($routes) > 0): ?>
                                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($route->id == $bus->route_code): ?>
                                                <a href="/routes/<?php echo e($bus->route_code); ?>"><?php echo e($route->route_name); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="/buses/<?php echo e($bus->id); ?>/edit" class="btn btn-success">
                                            <i class="ti-pencil-alt2"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['action' => ['BusesController@destroy', $bus->id], 'method' => 'POST']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <button type="submit" class="btn btn-danger">
                                                <i class="ti-eraser"></i>
                                            </button>
                                        <?php echo Form::close(); ?> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No buses found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>