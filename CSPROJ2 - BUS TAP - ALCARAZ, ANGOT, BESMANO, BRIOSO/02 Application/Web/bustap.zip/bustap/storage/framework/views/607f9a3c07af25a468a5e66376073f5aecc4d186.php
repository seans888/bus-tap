<?php $__env->startSection('title'); ?> - View Stop Information <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Stop Information</h4>
            </div>
            <div class="content">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Code</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $stop->stop_code; ?>">
                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group">
                                <label>Stop Name</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $stop->stop_name; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Location</label>
                                <p><a href="<?php echo $stop->stop_location; ?>"> Redirect to google map </a></p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Loads beep&trade; card?</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $stop->stop_loadbeep; ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Sells ticket?</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $stop->stop_sellticket; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label>Route</label>
                                <?php if(count($routes) > 0): ?>
                                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($route->id == $stop->route_code): ?>
                                            <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_name; ?>">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Order of stop</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $stop->stop_order; ?>">
                            </div>
                        </div>
                    </div>

                    <table>
                        <td width=100>
                            <a href="/stops/<?php echo e($stop->id); ?>/edit" class="btn btn-info btn-block">Edit</a>
                        </td>
                        <td width=25>&nbsp;</td>    
                        <td width=100>
                            <?php echo Form::open(['action' => ['StopsController@destroy', $stop->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

                            <?php echo Form::close(); ?> 
                        </td>            
                    </table>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>