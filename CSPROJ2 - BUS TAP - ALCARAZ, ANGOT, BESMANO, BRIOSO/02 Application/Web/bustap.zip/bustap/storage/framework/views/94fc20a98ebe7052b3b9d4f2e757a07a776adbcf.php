<?php $__env->startSection('title'); ?> - View BGC Bus News <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View BGC Bus News</h4>
            </div>
            <div class="content">
                <?php if(count($announcements) > 0): ?>
                    <table class="table">
                        <thead class="text-info">
                            <th>Date and Time Created</th>
                            <th>Title</th>
                            <th></th>
                            <th></th>    
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($announcement->created_at); ?></td>
                                    <td><a href="/news/<?php echo e($announcement->id); ?>"><?php echo e($announcement->news_title); ?></a></td>
                                    <td>
                                        <a href="/news/<?php echo e($announcement->id); ?>/edit" class="btn btn-success">
                                            <i class="ti-pencil-alt2"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['action' => ['NewsController@destroy', $announcement->id], 'method' => 'POST']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <button type="submit" class="btn btn-danger">
                                                <i class="ti-eraser"></i>
                                            </button>
                                        <?php echo Form::close(); ?> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No BGC Bus news found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>