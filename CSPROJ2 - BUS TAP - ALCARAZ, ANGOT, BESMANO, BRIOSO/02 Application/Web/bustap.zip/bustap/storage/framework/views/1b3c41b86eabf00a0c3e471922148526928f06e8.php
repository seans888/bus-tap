<?php $__env->startSection('title'); ?> - View Bus Stops <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Bus Stops</h4>
            </div>
            <div class="content">
                    <?php if(count($stops) > 0): ?>
                    <table class="table">
                        <thead class="text-info">
                            <th>Stop Code</th>
                            <th>Name</th>
                            <th>beep&trade;?</th>
                            <th>Ticket?</th>
                            <th>Route</th>
                            <th></th>
                            <th></th>    
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($stop->stop_code); ?></td>
                                    <td><a href="/stops/<?php echo e($stop->id); ?>"><?php echo e($stop->stop_name); ?></a></td>
                                    <td>
                                        <?php if($stop->stop_loadbeep == 'Y'): ?>
                                            <i class="ti-check"></i>
                                        <?php endif; ?>
                                        <?php if($stop->stop_loadbeep == 'N'): ?>
                                            <i class="ti-close"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($stop->stop_sellticket == 'Y'): ?>
                                            <i class="ti-check"></i>
                                        <?php endif; ?>
                                        <?php if($stop->stop_sellticket == 'N'): ?>
                                            <i class="ti-close"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(count($routes) > 0): ?>
                                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($route->id == $stop->route_code): ?>
                                                <a href="/routes/<?php echo e($stop->route_code); ?>"><?php echo e($route->route_name); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="/stops/<?php echo e($stop->id); ?>/edit" class="btn btn-success">
                                            <i class="ti-pencil-alt2"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['action' => ['StopsController@destroy', $stop->id], 'method' => 'POST']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <button type="submit" class="btn btn-danger">
                                                <i class="ti-eraser"></i>
                                            </button>
                                        <?php echo Form::close(); ?> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No bus stops found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>