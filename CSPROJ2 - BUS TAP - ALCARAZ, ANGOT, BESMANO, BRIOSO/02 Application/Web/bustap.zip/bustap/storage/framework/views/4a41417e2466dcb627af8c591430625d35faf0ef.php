<?php $__env->startSection('title'); ?> - View Schedule <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Schedule</h4>
            </div>
            <div class="content">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Date</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $schedule->sched_date1; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Arrival Time</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $schedule->sched_time1; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Departure Time</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $schedule->sched_time2; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Route</label>
                                <?php if(count($routes) > 0): ?>
                                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($route->id == $schedule->route_code): ?>
                                            <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_name; ?>">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <table>
                        <td width=100>
                            <a href="/schedules/<?php echo e($schedule->id); ?>/edit" class="btn btn-info btn-block">Edit</a>
                        </td>
                        <td width=25>&nbsp;</td>    
                        <td width=100>
                            <?php echo Form::open(['action' => ['SchedulesController@destroy', $schedule->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

                            <?php echo Form::close(); ?> 
                        </td>            
                    </table>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>