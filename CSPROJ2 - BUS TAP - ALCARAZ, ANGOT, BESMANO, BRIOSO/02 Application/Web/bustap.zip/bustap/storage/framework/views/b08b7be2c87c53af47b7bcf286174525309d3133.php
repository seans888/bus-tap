<?php $__env->startSection('title'); ?> - Add News <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">Add News</h4>
            </div>
            <div class="content">
                <?php echo Form::open(['action' => 'NewsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('news_title', 'Title')); ?>

                                <?php echo e(Form::text('news_title', '', ['class' => 'form-control border-input', 'placeholder' => 'Title'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('news_article', 'News Article')); ?>

                                <?php echo e(Form::textarea('news_article', '', ['class' => 'form-control border-input', 'placeholder' => 'News Article'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-success pull-left'])); ?>

                        <a href="/news" class="btn btn-info pull-right">Cancel</a>
                    </div>
                    <div class="clearfix"></div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>