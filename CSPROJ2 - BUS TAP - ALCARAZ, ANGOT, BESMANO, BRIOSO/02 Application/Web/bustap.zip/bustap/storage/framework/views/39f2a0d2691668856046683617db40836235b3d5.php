<?php $__env->startSection('title'); ?> - View Schedules <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Schedules</h4>
            </div>
            <div class="content">
                    <?php if(count($schedules) > 0): ?>
                    <table class="table">
                        <thead class="text-info">
                            <th>Date</th>
                            <th>Arrival Time</th>
                            <th>Departure Time</th>
                            <th>Route</th>
                            <th></th>
                            <th></th>    
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="/schedules/<?php echo e($schedule->id); ?>"><?php echo e($schedule->sched_date1); ?></a></td>
                                    <td><?php echo e($schedule->sched_time1); ?></td>
                                    <td><?php echo e($schedule->sched_time2); ?></td>
                                    <td>
                                        <?php if(count($routes) > 0): ?>
                                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($route->id == $schedule->route_code): ?>
                                                <a href="/routes/<?php echo e($schedule->route_code); ?>"><?php echo e($route->route_name); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="/schedules/<?php echo e($schedule->id); ?>/edit" class="btn btn-success">
                                            <i class="ti-pencil-alt2"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo Form::open(['action' => ['SchedulesController@destroy', $schedule->id], 'method' => 'POST']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <button type="submit" class="btn btn-danger">
                                                <i class="ti-eraser"></i>
                                            </button>
                                        <?php echo Form::close(); ?> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No schedules found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>