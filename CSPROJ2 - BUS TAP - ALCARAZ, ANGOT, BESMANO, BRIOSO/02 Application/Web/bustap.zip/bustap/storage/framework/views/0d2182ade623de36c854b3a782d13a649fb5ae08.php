<?php $__env->startSection('title'); ?> - Update Stop Information <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">Update Stop Information</h4>
            </div>
            <div class="content">
                    <?php echo Form::open(['action' => ['StopsController@update', $stop->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <?php echo e(Form::label('stop_code', 'Code')); ?>

                                <?php echo e(Form::text('stop_code', $stop->stop_code, ['class' => 'form-control border-input', 'placeholder' => 'Code'])); ?>

                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group">
                                <?php echo e(Form::label('stop_name', 'Stop Name')); ?>

                                <?php echo e(Form::text('stop_name', $stop->stop_name, ['class' => 'form-control border-input', 'placeholder' => 'Stop Name'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('stop_location', 'Location')); ?>

                                <?php echo e(Form::text('stop_location', $stop->stop_location, ['class' => 'form-control border-input', 'placeholder' => 'Location'])); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                    <?php echo e(Form::label('stop_loadbeep', 'Loads beep&trade; card?')); ?>

                                    <?php echo e(Form::text('stop_loadbeep', $stop->stop_loadbeep, ['class' => 'form-control border-input', 'placeholder' => 'Y/N'])); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                    <?php echo e(Form::label('stop_sellticket', 'Sells ticket?')); ?>

                                    <?php echo e(Form::text('stop_sellticket', $stop->stop_sellticket, ['class' => 'form-control border-input', 'placeholder' => 'Y/N'])); ?>

                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label for="route_code">Route</label>
                                <select class="form-control border-input" name="route_code">
                                    <?php if(count($routes) > 0): ?>
                                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($route->id == $stop->route_code): ?>
                                                <option value=<?php echo e($route->id); ?> selected> <?php echo e($route->route_name); ?> </option>
                                            <?php else: ?>
                                                <option value=<?php echo e($route->id); ?>> <?php echo e($route->route_name); ?> </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo e(Form::label('stop_order', 'Order of stop?')); ?>

                                <?php echo e(Form::number('stop_order', $stop->stop_order, ['class' => 'form-control border-input', 'placeholder' => 'Order'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                        <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-success pull-left'])); ?>

                        <a href="/stops" class="btn btn-info pull-right">Cancel</a>
                    </div>
                    <div class="clearfix"></div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>