<?php $__env->startSection('title'); ?> - View Bus Information <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Bus Information</h4>
            </div>
            <div class="content">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Plate Number</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $bus->bus_platenumber; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Status</label>
                                <input type="text" class="form-control border-input" disabled value="<?php echo $bus->bus_availability; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Route</label>
                                <?php if(count($routes) > 0): ?>
                                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($route->id == $bus->route_code): ?>
                                            <input type="text" class="form-control border-input" disabled value="<?php echo $route->route_name; ?>">
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <table>
                        <td width=100>
                            <a href="/bustap/public/buses/<?php echo e($bus->id); ?>/edit" class="btn btn-info btn-block">Edit</a>
                        </td>
                        <td width=25>&nbsp;</td>    
                        <td width=100>
                            <?php echo Form::open(['action' => ['BusesController@destroy', $bus->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block'])); ?>

                            <?php echo Form::close(); ?> 
                        </td>            
                    </table>
            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>