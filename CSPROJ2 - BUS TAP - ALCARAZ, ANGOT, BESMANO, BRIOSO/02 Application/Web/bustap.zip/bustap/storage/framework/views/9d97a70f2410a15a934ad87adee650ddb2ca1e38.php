<?php $__env->startSection('title'); ?> - View Feedbacks <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- Style for star rating -->
    <style>
        .checked {
            color: orangered;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">View Feedbacks</h4>
            </div>
            <div class="content">
                    <?php if(count($feedbacks) > 0): ?>
                    <table class="table">
                        <thead class="text-info">
                            <th>Date</th>
                            <th>Passenger Name</th>
                            <th>Feedback</th>
                            <th>Rating<th/>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($feedback->fb_date); ?></td>
                                    <td><?php echo e($feedback->user_name); ?></td>
                                    <td><?php echo e($feedback->fb_text); ?></td>
                                    <td>
                                        <?php if(($feedback->fb_rating >= 0.00) && ($feedback->fb_rating <= 0.49)): ?>
                                        <?php endif; ?>
                                
                                        <?php if(($feedback->fb_rating > 0.49) && ($feedback->fb_rating <= 1.49)): ?>
                                            <i class="ti-star checked"></i>
                                        <?php endif; ?>
                                                                                
                                        <?php if(($feedback->fb_rating > 1.49) && ($feedback->fb_rating <= 2.49)): ?>
                                            <i class="ti-star checked"></i>
                                            <i class="ti-star checked"></i>
                                        <?php endif; ?>
                                
                                        <?php if(($feedback->fb_rating > 2.49) && ($feedback->fb_rating <= 3.49)): ?>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <?php endif; ?>
                                
                                        <?php if(($feedback->fb_rating > 3.49) && ($feedback->fb_rating <= 4.49)): ?>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <?php endif; ?>
                                
                                        <?php if(($feedback->fb_rating > 4.49) && ($feedback->fb_rating <= 5.00)): ?>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <i class="ti-star checked"></i>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No feedbacks found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>