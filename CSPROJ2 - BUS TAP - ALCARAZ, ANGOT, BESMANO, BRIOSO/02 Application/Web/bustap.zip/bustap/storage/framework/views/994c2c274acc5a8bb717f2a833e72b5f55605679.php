<?php $__env->startSection('title'); ?> - Create Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> Create Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/background.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">Add Route</h4>
            </div>
            <div class="content">
                <?php echo Form::open(['action' => 'RoutesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <?php echo e(Form::label('route_code', 'Route Code')); ?>

                                <?php echo e(Form::text('route_code', '', ['class' => 'form-control border-input', 'placeholder' => 'Code'])); ?>

                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="form-group">
                                <?php echo e(Form::label('route_name', 'Route Name')); ?>

                                <?php echo e(Form::text('route_name', '', ['class' => 'form-control border-input', 'placeholder' => 'Route Name'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('route_availability', 'Status')); ?>

                                <?php echo e(Form::text('route_availability', '', ['class' => 'form-control border-input', 'placeholder' => 'Status'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <?php echo e(Form::label('route_opschedule', 'Operating Schedule')); ?>

                                <?php echo e(Form::text('route_opschedule', '', ['class' => 'form-control border-input', 'placeholder' => 'Operating Schedule'])); ?>                            
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo e(Form::label('route_fare', 'Bus Fare')); ?>

                                <?php echo e(Form::number('route_fare', '', ['class' => 'form-control border-input', 'placeholder' => 'Fare'])); ?>                            
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label> Route Map (max upload size: 2MB) </label> 
                                <?php echo e(Form::file('route_map')); ?>

                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-success pull-left'])); ?>

                        <a href="/routes" class="btn btn-info pull-right">Cancel</a>
                    </div>
                    <div class="clearfix"></div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>