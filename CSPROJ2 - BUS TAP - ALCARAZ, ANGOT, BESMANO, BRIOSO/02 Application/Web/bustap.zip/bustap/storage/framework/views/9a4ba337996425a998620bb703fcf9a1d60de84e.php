<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Favicon -->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>"/>
        
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href=" <?php echo e(asset('paper-dashboard/css/bootstrap.min.css')); ?>" />

        <!-- Animation library for notifications -->
        <link rel="stylesheet" href=" <?php echo e(asset('paper-dashboard/css/animate.min.css')); ?>" />

        <!-- Paper Dashboard core CSS -->
        <link rel="stylesheet" href=" <?php echo e(asset('paper-dashboard/css/paper-dashboard.css')); ?>" />

        <!-- Fonts and icons -->
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" >
        <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Muli:400,300' type='text/css'>
        <link rel="stylesheet" href=" <?php echo e(asset('paper-dashboard/css/themify-icons.css')); ?>" >
        
        <?php echo $__env->yieldContent('style'); ?>
        
        <!-- Title -->
        <title><?php echo e(config('app.name', 'Bus Tap')); ?> <?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('inc.sidebar-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="main-panel">
                <?php echo $__env->make('inc.navbar-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="content" <?php echo $__env->yieldContent('background'); ?>>
                    <div class="container-fluid">
                        <div class="row">
                            <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

                <?php echo $__env->make('inc.footer-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </body>
    <!-- Core JS Files -->
    <script type="text/javascript" src="<?php echo e(asset('paper-dashboard/js/jquery-1.10.2.js')); ?>" ></script>
	<script type="text/javascript" src="<?php echo e(asset('paper-dashboard/js/bootstrap.min.js')); ?>" ></script>
    
    <!-- Checkbox, Radio & Switch Plugins -->
	<script src="<?php echo e(asset('paper-dashboard/js/bootstrap-checkbox-radio.js')); ?>"></script>

    <!-- Text Editor Plugin -->
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>

</html>