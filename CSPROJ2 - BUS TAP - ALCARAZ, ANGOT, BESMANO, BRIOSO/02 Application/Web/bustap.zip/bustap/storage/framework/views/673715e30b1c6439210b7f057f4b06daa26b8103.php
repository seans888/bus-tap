<?php $__env->startSection('title'); ?> - Sign In <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> SIGN IN <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form class="register-form" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="email">E-Mail Address</label>
            <div>
                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required autofocus>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
                    
        <div>
            <label for="password">Password</label>
            <div>
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                 <?php endif; ?>
            </div>
        </div>
        &nbsp;

        <div>
            <div>
                <div class="checkbox">
                    <label>
                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                    </label>
                </div>
            </div>
        </div>
        &nbsp;

        <div>
            <div>
                <button type="submit" class="btn btn-block btn-info">
                    SIGN IN
                </button>
            </div>
        </div>

        <div>
            <div>                     
                <a class="btn btn-block btn-link" href="<?php echo e(route('password.request')); ?>" style="color: white;">
                    Forgot Your Password?
                </a>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-accounts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>