<?php $__env->startSection('title'); ?> - Add Bus <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>  <?php $__env->stopSection(); ?>
<?php $__env->startSection('background'); ?> 
    style="background-image: url('<?php echo e(asset('img/welcome_page_1600.jpg')); ?>'); 
    background-repeat: round; 
    background-attachment: fixed;"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-7">
        <div class="card">
            <div class="header">
                <h4 class="title">Add Bus</h4>
            </div>
            <div class="content">
                <?php echo Form::open(['action' => 'BusesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('bus_platenumber', 'Plate Number')); ?>

                                <?php echo e(Form::text('bus_platenumber', '', ['class' => 'form-control border-input', 'placeholder' => 'Plate Number'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo e(Form::label('bus_availability', 'Status')); ?>

                                <?php echo e(Form::text('bus_availability', '', ['class' => 'form-control border-input', 'placeholder' => 'Status'])); ?>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="route_code">Route</label>
                                <select class="form-control border-input" name="route_code">
                                    <?php if(count($routes) > 0): ?>
                                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value=<?php echo e($route->id); ?>> <?php echo e($route->route_name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="text-center">
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-success pull-left'])); ?>

                        <a href="/buses" class="btn btn-info pull-right">Cancel</a>
                    </div>
                    <div class="clearfix"></div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>      
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>