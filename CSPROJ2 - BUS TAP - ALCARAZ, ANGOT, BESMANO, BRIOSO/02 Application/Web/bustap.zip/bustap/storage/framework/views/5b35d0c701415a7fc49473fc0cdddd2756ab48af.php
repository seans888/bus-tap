<?php $__env->startSection('title'); ?> - Reset Password <?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?> RESET PASSWORD <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form class="register-form" method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="email">E-Mail Address</label>
            <div>
                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        &nbsp;

        <div>
            <div>
                <button type="submit" class="btn btn-block btn-info">
                    Send Password Reset Link
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-accounts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>