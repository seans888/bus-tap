<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Congestion extends Model
{
    //
}
