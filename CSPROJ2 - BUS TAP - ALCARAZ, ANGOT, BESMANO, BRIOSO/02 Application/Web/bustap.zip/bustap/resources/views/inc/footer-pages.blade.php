    <footer class="footer navbar-ct-danger">
        <div class="container-fluid">
            <div class="copyright pull-left">
                &copy; Bus Tap <script>document.write(new Date().getFullYear())</script>, made by Anna Alcaraz, Sammy Angot, Justin Besmano, and Job Brioso
            </div>
        </div>
    </footer>