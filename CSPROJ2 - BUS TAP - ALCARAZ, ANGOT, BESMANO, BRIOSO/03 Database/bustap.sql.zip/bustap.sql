-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2018 at 05:18 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bustap`
--

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `id` int(10) UNSIGNED NOT NULL,
  `bus_platenumber` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bus_availability` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_code` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`id`, `bus_platenumber`, `bus_availability`, `route_code`, `created_at`, `updated_at`) VALUES
(1, 'ABC-321', 'Operational', 2, '2018-04-18 13:37:32', '2018-04-25 12:23:35'),
(2, 'XYZ-963', 'Operational', 7, '2018-04-18 13:38:09', '2018-04-25 12:24:26');

-- --------------------------------------------------------

--
-- Table structure for table `congestions`
--

CREATE TABLE `congestions` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `fb_date` date NOT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fb_text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fb_rating` double(3,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `fb_date`, `user_name`, `fb_text`, `fb_rating`, `created_at`, `updated_at`) VALUES
(1, '2018-04-19', 'Anna Alcaraz', 'The Night Route bus arrived at the EDSA Ayala Terminal at exactly 10PM, and departed on time. Keep up the good work in keeping the bus schedules on time.', 5.00, NULL, NULL),
(2, '2018-04-18', 'Sammy Angot', 'Buses for the night route should come at intervals less than 30 minutes. If a passenger is left by the bus, should the passenger really wait 30 minutes for the next bus?!', 2.00, NULL, NULL),
(3, '2018-04-17', 'Justin Besmano', 'More buses should be deployed at the EDSA Ayala Terminal during rush hours. The terminal gets so congested inside the terminal because only few buses arrive to pick up the passengers.', 3.00, NULL, NULL),
(4, '2018-04-16', 'Job Brioso', 'Thank you for adding the East Express bus route. I can now travel directly from Ayala to Market Market. My travel time has now become so much faster.', 5.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(93, '2014_10_12_000000_create_users_table', 1),
(94, '2014_10_12_100000_create_password_resets_table', 1),
(95, '2018_03_04_094821_create_routes_table', 1),
(96, '2018_03_04_103116_create_stops_table', 1),
(97, '2018_04_03_194756_add_user_type_to_users_table', 1),
(98, '2018_04_03_223615_create_employees_table', 1),
(99, '2018_04_03_223714_create_buses_table', 1),
(100, '2018_04_03_223800_create_schedules_table', 1),
(101, '2018_04_03_223832_create_news_table', 1),
(102, '2018_04_03_223907_create_congestions_table', 1),
(103, '2018_04_03_223949_create_feedback_table', 1),
(104, '2018_04_03_224027_create_reservations_table', 1),
(105, '2018_04_04_010908_add_route_map_to_routes_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) UNSIGNED NOT NULL,
  `news_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `news_article` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `news_title`, `news_article`, `created_at`, `updated_at`) VALUES
(1, 'BGC rolls out express buses, new routes', '<p align=\"justify\">After collecting and studying historical data of foot traffic and travel time, BGC has made improvements to their bus service and are rolling out express buses to cater to commuters\' needs starting August 7 (Monday).</p>\r\n\r\n<p align=\"justify\">\"By assessing historical data, we have come up with a system to help alleviate passenger wait time so BGCitizens and guests can reach their destinations safely and conveniently within the shortest time possible,\" BGC’s Marketing Manager Sean Luarca said in a statement shared with the press.</p>\r\n\r\n<p align=\"justify\">The East Express bus will travel point-to-point from EDSA Ayala to Market! Market!</p>\r\n\r\n<p align=\"justify\">The Upper West Express bus will have two stops from EDSA Ayala: Bonifacio Stopover and Crescent Park West.</p>\r\n\r\n<p align=\"justify\">The Lower West Express bus will have three stops from EDSA Ayala: RCBC, Net One, and Fort Victoria.</p>\r\n\r\n<p align=\"justify\">The North Express bus will have four stops from EDSA Ayala: HSBC, The Globe Tower, Nutriasia, and BGC Turf.</p>\r\n\r\n<p align=\"justify\">Each express bus will service commuters from 6 am to 10 pm.</p>', '2018-04-18 12:28:38', '2018-04-18 12:37:41');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(10) UNSIGNED NOT NULL,
  `res_date` date NOT NULL,
  `res_time` time NOT NULL,
  `route_code` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `res_date`, `res_time`, `route_code`, `user_name`, `created_at`, `updated_at`) VALUES
(1, '2018-04-19', '22:00:00', 7, 'Anna Alcaraz', NULL, NULL),
(2, '2018-04-19', '22:30:00', 7, 'Sammy Angot', NULL, NULL),
(3, '2018-04-19', '23:00:00', 7, 'Justin Besmano', NULL, NULL),
(4, '2018-04-19', '23:30:00', 7, 'Job Brioso', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(10) UNSIGNED NOT NULL,
  `route_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_availability` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_opschedule` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_fare` decimal(4,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route_map` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `route_code`, `route_name`, `route_availability`, `route_opschedule`, `route_fare`, `created_at`, `updated_at`, `route_map`) VALUES
(1, 'NX', 'North Express', 'Operational', 'Mon to Fri 6AM to 10PM', '12.00', '2018-04-18 12:42:05', '2018-04-18 12:42:05', 'North Express Route_1524084125.jpg'),
(2, 'WX', 'Upper West Express', 'Operational', 'Mon to Fri 6AM to 10PM', '12.00', '2018-04-18 12:43:43', '2018-04-18 12:43:43', 'Upper West Express Route_1524084223.jpg'),
(3, 'L', 'Lower West Express', 'Operational', 'Mon to Fri 6AM to 10PM', '12.00', '2018-04-18 12:44:35', '2018-04-18 12:44:35', 'Lower West Express Route_1524084274.jpg'),
(4, 'EX', 'East Express Route', 'Operational', 'Mon to Fri 6AM to 10PM', '12.00', '2018-04-18 12:45:14', '2018-04-18 12:45:14', 'East Express Route_1524084314.jpg'),
(5, 'C', 'Central Route', 'Operational', 'Mon to Sun 6AM to 10PM', '12.00', '2018-04-18 12:46:48', '2018-04-18 12:48:35', 'no_image.png'),
(6, 'N', 'North Route', 'Operational', 'Mon to Fri 6:30AM to 10AM & 4:30PM to 8:30PM', '12.00', '2018-04-18 12:48:19', '2018-04-18 12:48:19', 'North Route_1524084499.jpg'),
(7, 'NR', 'Night Route', 'Operational', 'Mon to Sun 10PM - 6AM', '12.00', '2018-04-18 12:49:39', '2018-04-18 12:49:39', 'Night Route_1524084579.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `sched_date1` date NOT NULL,
  `sched_time1` time NOT NULL,
  `sched_time2` time NOT NULL,
  `route_code` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `sched_date1`, `sched_time1`, `sched_time2`, `route_code`, `created_at`, `updated_at`) VALUES
(1, '2018-04-19', '22:00:00', '22:05:00', 7, '2018-04-18 13:38:57', '2018-04-18 13:38:57'),
(2, '2018-04-19', '22:30:00', '22:35:00', 7, '2018-04-18 13:39:40', '2018-04-18 13:39:40'),
(3, '2018-04-19', '23:00:00', '23:05:00', 7, '2018-04-18 13:40:24', '2018-04-18 13:40:24'),
(4, '2018-04-19', '23:30:00', '23:35:00', 7, '2018-04-18 13:40:56', '2018-04-18 13:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `stops`
--

CREATE TABLE `stops` (
  `id` int(10) UNSIGNED NOT NULL,
  `stop_code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_loadbeep` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stop_sellticket` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_code` int(10) UNSIGNED NOT NULL,
  `stop_order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stops`
--

INSERT INTO `stops` (`id`, `stop_code`, `stop_name`, `stop_location`, `stop_loadbeep`, `stop_sellticket`, `route_code`, `stop_order`, `created_at`, `updated_at`) VALUES
(5, 'WX03', 'Crescent Park West', 'https://www.google.com.ph/maps/@14.5544731,121.0439033,3a,60y,239.23h,84.74t/data=!3m6!1e1!3m4!1sdGKp8LSOopj2glKYpdvaFg!2e0!7i13312!8i6656', 'N', 'Y', 2, 3, '2018-04-18 13:25:13', '2018-04-18 13:25:13'),
(6, 'WX01', 'EDSA Ayala', 'https://www.google.com.ph/maps/@14.5491419,121.0291919,3a,75y,23.28h,87.89t/data=!3m6!1e1!3m4!1szM2_CuLFw_sOEuwjSnCZOA!2e0!7i13312!8i6656', 'Y', 'Y', 2, 1, '2018-04-18 13:32:17', '2018-04-18 13:33:30'),
(7, 'WX02', 'Bonifacio Stopover', 'https://www.google.com.ph/maps/@14.5541463,121.0459368,3a,75y,339.72h,90.8t/data=!3m6!1e1!3m4!1sEAAGI5ZxNfgQwAk5jjTJPQ!2e0!7i13312!8i6656', 'Y', 'Y', 2, 2, '2018-04-18 13:36:21', '2018-04-18 13:36:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `user_type`) VALUES
(1, 'Juan Dela Cruz', 'acalcaraz@student.apc.edu.ph', '$2y$10$eWOSkjiO2Ioyom2rLeJ4Y.PBK/PvepSA7PtSYLheXas/.D8zAyJwi', 'yxlQegSx64D4QL2Ytuimn39rFkm2sW8cRMLKILY2dH4UwjZcnytfTzlvqWvI', '2018-04-18 12:24:08', '2018-04-25 12:13:45', 'Employee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buses_route_code_foreign` (`route_code`);

--
-- Indexes for table `congestions`
--
ALTER TABLE `congestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservations_route_code_foreign` (`route_code`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `routes_route_code_unique` (`route_code`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `schedules_route_code_foreign` (`route_code`);

--
-- Indexes for table `stops`
--
ALTER TABLE `stops`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stops_stop_code_unique` (`stop_code`),
  ADD KEY `stops_route_code_foreign` (`route_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `congestions`
--
ALTER TABLE `congestions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stops`
--
ALTER TABLE `stops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buses`
--
ALTER TABLE `buses`
  ADD CONSTRAINT `buses_route_code_foreign` FOREIGN KEY (`route_code`) REFERENCES `routes` (`id`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_route_code_foreign` FOREIGN KEY (`route_code`) REFERENCES `routes` (`id`);

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_route_code_foreign` FOREIGN KEY (`route_code`) REFERENCES `routes` (`id`);

--
-- Constraints for table `stops`
--
ALTER TABLE `stops`
  ADD CONSTRAINT `stops_route_code_foreign` FOREIGN KEY (`route_code`) REFERENCES `routes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
